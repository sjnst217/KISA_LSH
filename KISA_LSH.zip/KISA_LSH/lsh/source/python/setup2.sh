#!
python2 setup.py sdist
sudo python2 setup.py install
